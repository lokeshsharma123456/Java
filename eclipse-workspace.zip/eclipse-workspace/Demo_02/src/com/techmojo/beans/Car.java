package com.techmojo.beans;

public interface Car {
	public void turnDirection();
	public void accelerate();
	public void stop();
}
