package com.techmojo.beans;

public class Salavia implements Car {

	@Override
	public void turnDirection() {
		// TODO Auto-generated method stub
		System.out.println("Turn the direction of Salavia");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("Accelerate Salavia->>>>>>>>>>");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("Stop the  Salavia|--");
	}
	
	public void roofTop() {
		System.out.println("Salavia has crazy rooftop");
	}

}
