package com.techmojo.beans;

public class Fortuner implements Car {

	@Override
	public void turnDirection() {
		// TODO Auto-generated method stub
		System.out.println("Turn the direction");

	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("Accelerate ->>>>>>>>>>");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("Stop the care |--");
		
	}
	
	public void fourWheel() {
		// TODO Auto-generated method stub
		System.out.println("Fourtuener wheels are shiny and speedy--");
		
	}
	
	

}
