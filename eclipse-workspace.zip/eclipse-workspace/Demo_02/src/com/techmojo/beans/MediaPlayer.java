package com.techmojo.beans;

public interface MediaPlayer {
	void play();
	void pause();
	void volumeUp();
	void volumeDown();
	
}
