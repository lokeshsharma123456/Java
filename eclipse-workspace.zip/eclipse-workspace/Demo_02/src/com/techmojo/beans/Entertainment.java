package com.techmojo.beans;

public interface Entertainment {
	void watchMovie();
	void listenSong();
}
