package com.techmojo.beans;

public interface Vehicle {
	public void turn();
	public void stop();
	public void accelerate();
}	
