package com.techmojo.exception;

public class NonParsableContentException extends Exception {

	public NonParsableContentException() {
		// TODO Auto-generated constructor stub
	}

	public NonParsableContentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NonParsableContentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NonParsableContentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NonParsableContentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
