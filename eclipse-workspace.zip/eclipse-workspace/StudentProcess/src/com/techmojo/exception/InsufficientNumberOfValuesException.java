package com.techmojo.exception;

public class InsufficientNumberOfValuesException extends Exception {

	public InsufficientNumberOfValuesException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientNumberOfValuesException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InsufficientNumberOfValuesException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsufficientNumberOfValuesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InsufficientNumberOfValuesException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
