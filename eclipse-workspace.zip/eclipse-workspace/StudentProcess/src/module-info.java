/**
 * 
 */
/**
 * 
 */
module StudentProcess {
	requires log4j;
}