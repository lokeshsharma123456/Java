/**
 * 
 */
/**
 * 
 */
module CollectionExercise {
	requires lombok;
}