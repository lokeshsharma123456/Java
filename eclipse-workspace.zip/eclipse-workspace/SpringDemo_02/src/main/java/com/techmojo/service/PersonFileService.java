package com.techmojo.service;

import com.techmojo.beans.Person;

public class PersonFileService implements PersonService{

	public PersonFileService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void save(Person p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Person find() {
		// TODO Auto-generated method stub
		return null;
	}

}
