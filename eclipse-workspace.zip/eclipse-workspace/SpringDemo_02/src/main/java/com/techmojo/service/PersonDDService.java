package com.techmojo.service;

import com.techmojo.beans.Person;

public class PersonDDService implements PersonService{

	 
	@Override
	public Person find() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Person p) {
		// TODO Auto-generated method stub
		
	}

}
