package com.techmojo.app;

import com.techmojo.beans.RegularEmp;

public class RegularEmpApp_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RegularEmp regEmp = new RegularEmp(101, "Lokesh", "lokesh@gmail.com", 78.99);
		System.out.println(regEmp);
	}
	 
}
