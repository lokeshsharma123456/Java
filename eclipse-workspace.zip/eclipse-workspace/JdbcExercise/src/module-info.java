/**
 * 
 */
/**
 * 
 */
module JdbcExercise {
	requires java.sql;
}